import { create } from "zustand";

export type MerchantSale = {
  name: string;
  current: number;
  previous: number;
};

export type Campaign = {
  id: string;
  campaign: string;
  subject: string;
  creativeLink: string;
  date: string;
  openRate: number;
  spend: number;
  merchants: string[];
  periodFrom: string;
  periodTo: string;
  customers: number;
  merchantSales: MerchantSale[];
  createdAt: string;
};

export type CampaignDraft = {
  campaign: string;
  subject: string;
  creativeLink: string;
  date: string;
  openRate: number;
  spend: number;
  merchants: string[];
};

const STORAGE_KEY = "mobicred-dashboard-records-v1";

export const money = (n: number) =>
  new Intl.NumberFormat("en-ZA", {
    style: "currency",
    currency: "ZAR",
    maximumFractionDigits: 0,
  }).format(Number.isFinite(n) ? n : 0);

function uid() {
  return `local-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

const SEED: Campaign[] = [
  {
    id: "seed-spend-voucher",
    campaign: "Spend R600 Get R200 Voucher",
    subject: "Shop with Mobicred — R200 voucher waiting for you",
    creativeLink: "https://mobicred.co.za/competitions-and-promotions",
    date: "2026-09-15",
    openRate: 31.4,
    spend: 184500,
    merchants: ["Takealot", "Checkers Sixty60", "Superbalist"],
    periodFrom: "2026-09-15",
    periodTo: "2026-09-21",
    customers: 12840,
    merchantSales: [
      { name: "Takealot", current: 92000, previous: 71000 },
      { name: "Checkers Sixty60", current: 54000, previous: 61000 },
      { name: "Superbalist", current: 38500, previous: 30200 },
    ],
    createdAt: "2026-09-15T08:00:00.000Z",
  },
  {
    id: "seed-takealot-credit",
    campaign: "takealot.credit R500 Mailer",
    subject: "Apply, shop, get a R500 Takealot voucher",
    creativeLink: "https://mobicred.co.za",
    date: "2026-09-08",
    openRate: 26.8,
    spend: 156200,
    merchants: ["Takealot"],
    periodFrom: "2026-09-08",
    periodTo: "2026-09-14",
    customers: 9640,
    merchantSales: [{ name: "Takealot", current: 156200, previous: 128400 }],
    createdAt: "2026-09-08T09:30:00.000Z",
  },
  {
    id: "seed-sixty60",
    campaign: "Checkers Sixty60 Pay with Mobicred",
    subject: "Groceries in 60 minutes — pay the Mobicred way",
    creativeLink: "https://mobicred.co.za",
    date: "2026-08-28",
    openRate: 22.1,
    spend: 97800,
    merchants: ["Checkers Sixty60", "Shoprite"],
    periodFrom: "2026-08-28",
    periodTo: "2026-09-04",
    customers: 7420,
    merchantSales: [
      { name: "Checkers Sixty60", current: 71200, previous: 68800 },
      { name: "Shoprite", current: 26600, previous: 30100 },
    ],
    createdAt: "2026-08-28T07:45:00.000Z",
  },
  {
    id: "seed-spend-win",
    campaign: "Mobicred Spend & Win 2026",
    subject: "Every swipe is an entry — spend and win this month",
    creativeLink: "https://mobicred.co.za/competitions-and-promotions",
    date: "2026-08-12",
    openRate: 34.9,
    spend: 211400,
    merchants: ["Makro", "Game", "Mr Price"],
    periodFrom: "2026-08-12",
    periodTo: "2026-08-31",
    customers: 18620,
    merchantSales: [
      { name: "Makro", current: 98400, previous: 81200 },
      { name: "Game", current: 67300, previous: 70500 },
      { name: "Mr Price", current: 45700, previous: 38900 },
    ],
    createdAt: "2026-08-12T10:00:00.000Z",
  },
  {
    id: "seed-woolworths",
    campaign: "Woolworths Weekend Edit",
    subject: "The weekend edit is live — pay later with Mobicred",
    creativeLink: "https://mobicred.co.za",
    date: "2026-07-25",
    openRate: 19.6,
    spend: 64300,
    merchants: ["Woolworths", "Superbalist"],
    periodFrom: "2026-07-25",
    periodTo: "2026-07-27",
    customers: 4180,
    merchantSales: [
      { name: "Woolworths", current: 41200, previous: 39800 },
      { name: "Superbalist", current: 23100, previous: 27400 },
    ],
    createdAt: "2026-07-25T11:20:00.000Z",
  },
];

function readStorage(): Campaign[] | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw === null) return null;
    const parsed = JSON.parse(raw) as Campaign[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeStorage(records: Campaign[]) {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

type DashboardState = {
  records: Campaign[];
  hydrated: boolean;
  hydrate: () => void;
  refresh: () => void;
  create: (draft: CampaignDraft) => void;
  update: (id: string, patch: Partial<Campaign>) => void;
  remove: (id: string) => void;
  loadSample: () => void;
};

export const useDashboard = create<DashboardState>((set, get) => ({
  records: SEED,
  hydrated: false,
  hydrate: () => {
    const stored = readStorage();
    const records = stored ?? SEED;
    if (stored === null) writeStorage(records);
    set({ records, hydrated: true });
  },
  refresh: () => {
    const stored = readStorage();
    set({ records: stored ?? get().records });
  },
  create: (draft) => {
    const record: Campaign = {
      id: uid(),
      campaign: draft.campaign,
      subject: draft.subject,
      creativeLink: draft.creativeLink,
      date: draft.date,
      openRate: draft.openRate,
      spend: draft.spend,
      merchants: draft.merchants,
      periodFrom: "",
      periodTo: "",
      customers: 0,
      merchantSales: draft.merchants.map((name) => ({
        name,
        current: 0,
        previous: 0,
      })),
      createdAt: new Date().toISOString(),
    };
    const records = [...get().records, record];
    writeStorage(records);
    set({ records });
  },
  update: (id, patch) => {
    const records = get().records.map((item) =>
      item.id === id ? { ...item, ...patch, id: item.id } : item,
    );
    writeStorage(records);
    set({ records });
  },
  remove: (id) => {
    const records = get().records.filter((item) => item.id !== id);
    writeStorage(records);
    set({ records });
  },
  loadSample: () => {
    writeStorage(SEED);
    set({ records: SEED });
  },
}));

export function sortedCampaigns(records: Campaign[]) {
  return [...records].sort((a, b) => {
    const byDate = new Date(b.date).getTime() - new Date(a.date).getTime();
    if (byDate !== 0) return byDate;
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });
}

export function matchesQuery(record: Campaign, query: string) {
  if (!query) return true;
  const hay = `${record.campaign} ${record.subject} ${record.merchants.join(" ")}`.toLowerCase();
  return hay.includes(query.toLowerCase());
}

export function kpiTotals(records: Campaign[]) {
  const total = records.length;
  const open =
    total === 0
      ? 0
      : records.reduce((sum, item) => sum + Number(item.openRate || 0), 0) / total;
  const spend = records.reduce((sum, item) => sum + Number(item.spend || 0), 0);
  return { total, open, spend };
}

export type MerchantInsight = {
  name: string;
  count: number;
  avgOpen: number;
  spend: number;
};

export function merchantInsights(records: Campaign[]): MerchantInsight[] {
  const map = new Map<string, { count: number; open: number; spend: number }>();
  for (const record of records) {
    for (const name of record.merchants) {
      const current = map.get(name) ?? { count: 0, open: 0, spend: 0 };
      current.count += 1;
      current.open += Number(record.openRate || 0);
      current.spend += Number(record.spend || 0);
      map.set(name, current);
    }
  }
  return [...map.entries()]
    .map(([name, value]) => ({
      name,
      count: value.count,
      avgOpen: value.open / value.count,
      spend: value.spend,
    }))
    .sort((a, b) => b.spend - a.spend)
    .slice(0, 5);
}

export function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

export function movement(current: number, previous: number) {
  const delta = current - previous;
  const pct = previous ? (delta / previous) * 100 : 0;
  const direction: "up" | "down" | "flat" =
    delta > 0 ? "up" : delta < 0 ? "down" : "flat";
  const label = delta > 0 ? "Up" : delta < 0 ? "Down" : "No change";
  return { delta, pct, direction, label };
}
