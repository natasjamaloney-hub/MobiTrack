import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  Activity,
  Banknote,
  Database,
  Eye,
  Inbox,
  Mail,
  MailOpen,
  Pencil,
  Radio,
  RefreshCw,
  Search,
  ShieldCheck,
  Trash2,
} from "lucide-react";
import { CampaignForm } from "@/components/campaign-form";
import { PerformanceDialog } from "@/components/performance-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  kpiTotals,
  matchesQuery,
  merchantInsights,
  money,
  sortedCampaigns,
  useDashboard,
  type Campaign,
  type CampaignDraft,
} from "@/lib/campaigns";

export function Dashboard() {
  const records = useDashboard((state) => state.records);
  const hydrated = useDashboard((state) => state.hydrated);
  const hydrate = useDashboard((state) => state.hydrate);
  const refresh = useDashboard((state) => state.refresh);
  const create = useDashboard((state) => state.create);
  const update = useDashboard((state) => state.update);
  const remove = useDashboard((state) => state.remove);
  const loadSample = useDashboard((state) => state.loadSample);

  const [query, setQuery] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [viewingId, setViewingId] = useState<string | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    if (!confirmId) return;
    const timer = window.setTimeout(() => setConfirmId(null), 2600);
    return () => window.clearTimeout(timer);
  }, [confirmId]);

  const editing = records.find((item) => item.id === editingId) ?? null;
  const viewing = records.find((item) => item.id === viewingId) ?? null;
  const visible = useMemo(
    () => sortedCampaigns(records).filter((item) => matchesQuery(item, query)),
    [records, query],
  );
  const kpis = useMemo(() => kpiTotals(records), [records]);
  const insights = useMemo(() => merchantInsights(records), [records]);

  function handleSave(draft: CampaignDraft) {
    if (editing) {
      const merchantsChanged =
        draft.merchants.join("|") !== editing.merchants.join("|");
      update(editing.id, {
        ...draft,
        merchantSales: merchantsChanged
          ? draft.merchants.map((name) => {
              const existing = editing.merchantSales.find((item) => item.name === name);
              return existing ?? { name, current: 0, previous: 0 };
            })
          : editing.merchantSales,
      });
      setEditingId(null);
      return;
    }
    create(draft);
  }

  function handleDelete(id: string) {
    if (confirmId !== id) {
      setConfirmId(id);
      return;
    }
    remove(id);
    setConfirmId(null);
    if (editingId === id) setEditingId(null);
  }

  return (
    <div className="min-h-dvh bg-canvas text-ink">
      <header className="bg-ink text-white">
        <div className="h-1.5 bg-gold" />
        <div className="mx-auto flex h-[76px] w-full max-w-[1440px] items-center justify-between px-5 md:px-7">
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-xl bg-brand text-xl font-extrabold text-white">
              M
            </div>
            <div>
              <div className="text-sm font-extrabold tracking-brand">MOBICRED</div>
              <div className="text-xs font-semibold tracking-wide text-gold">
                MARKETING INTELLIGENCE
              </div>
            </div>
          </div>
          <div className="hidden items-center gap-2 text-sm font-semibold text-gold sm:flex">
            <Activity className="size-4" />
            Live Dashboard + Performance Eye
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-[1440px] px-4 py-7 md:px-7">
        <section className="rounded-2xl bg-surface p-5 shadow-panel md:p-8">
          <div className="flex flex-col gap-6 xl:flex-row xl:items-start xl:justify-between">
            <div>
              <p className="mb-2 text-xs font-bold tracking-kicker text-brand uppercase">
                Internal campaign workspace
              </p>
              <h1 className="text-3xl leading-tight font-extrabold text-ink md:text-4xl">
                Mobicred Marketing
              </h1>
              <p className="mt-2 text-muted">Email Performance Overview - Live</p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <span
                className="inline-flex items-center gap-2 rounded-full bg-gold-wash px-3 py-2 text-xs font-bold text-gold-ink"
                aria-live="polite"
              >
                <Database className="size-4" />
                Local storage
              </span>
              <Button type="button" size="sm" onClick={refresh}>
                <RefreshCw className="size-4" />
                Refresh
              </Button>
            </div>
          </div>

          <div className="mt-7 grid grid-cols-1 items-center gap-4 lg:grid-cols-[1fr_auto]">
            <label className="relative block">
              <span className="sr-only">Search campaigns</span>
              <Search className="absolute top-1/2 left-4 size-5 -translate-y-1/2 text-faint" />
              <Input
                className="border-line bg-search py-3.5 pr-4 pl-11"
                type="search"
                placeholder="Search campaigns, merchants or subject lines"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
              />
            </label>
            <span className="text-sm text-muted">
              <strong className="text-ink">{records.length}</strong> records
            </span>
          </div>

          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
            <KpiCard label="Total" icon={<Mail className="size-5 text-brand" />} value={String(kpis.total)} />
            <KpiCard
              label="Avg Open"
              icon={<MailOpen className="size-5 text-brand" />}
              value={`${kpis.open.toFixed(1)}%`}
            />
            <KpiCard
              label="Spend"
              icon={<Banknote className="size-5 text-brand" />}
              value={money(kpis.spend)}
            />
          </div>

          <section className="mt-8" aria-labelledby="records-heading">
            <div className="mb-3 flex items-center justify-between">
              <h2 id="records-heading" className="text-xl font-extrabold text-ink">
                Campaign Records
              </h2>
            </div>

            {visible.length === 0 ? (
              <div className="rounded-2xl border-2 border-dashed border-line px-5 py-12 text-center">
                <Inbox className="mx-auto mb-3 size-9 text-brand" />
                <p className="font-extrabold text-ink">
                  {!hydrated
                    ? "Loading campaign records"
                    : records.length === 0
                      ? "No campaign records yet"
                      : "No matching campaigns"}
                </p>
                <p className="mt-2 text-sm text-subtle">
                  {!hydrated
                    ? "Pulling mailer records from this device."
                    : records.length === 0
                      ? "Add your first mailer record below to bring this dashboard to life."
                      : "Try a different search, or clear the filter to see every record."}
                </p>
                {hydrated && records.length === 0 ? (
                  <Button type="button" className="mt-5" onClick={loadSample}>
                    Load sample campaigns
                  </Button>
                ) : null}
              </div>
            ) : (
              <>
                <div className="hidden overflow-x-auto rounded-2xl border border-line md:block">
                  <table className="min-w-full text-sm">
                    <thead className="bg-ink text-white">
                      <tr>
                        <th className="px-4 py-4 text-left font-bold">Date</th>
                        <th className="px-4 py-4 text-left font-bold">Campaign</th>
                        <th className="px-4 py-4 text-left font-bold">Merchants</th>
                        <th className="px-4 py-4 text-left font-bold">Open</th>
                        <th className="px-4 py-4 text-left font-bold">Spend</th>
                        <th className="px-4 py-4 text-right font-bold">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {visible.map((record) => (
                        <tr key={record.id} className="border-t border-line-soft hover:bg-search">
                          <td className="px-4 py-4 whitespace-nowrap">{record.date}</td>
                          <td className="px-4 py-4">
                            <strong>{record.campaign}</strong>
                            <div className="mt-1 text-xs text-subtle">
                              {record.subject || "No subject line"}
                            </div>
                          </td>
                          <td className="px-4 py-4">
                            {record.merchants.join(", ") || "—"}
                          </td>
                          <td className="px-4 py-4 font-bold">
                            {Number(record.openRate || 0).toFixed(1)}%
                          </td>
                          <td className="px-4 py-4 font-bold">{money(record.spend)}</td>
                          <td className="px-4 py-4">
                            <RecordActions
                              record={record}
                              confirmId={confirmId}
                              onView={() => setViewingId(record.id)}
                              onEdit={() => {
                                setEditingId(record.id);
                                document
                                  .getElementById("mailer-form")
                                  ?.scrollIntoView({ behavior: "smooth", block: "start" });
                              }}
                              onDelete={() => handleDelete(record.id)}
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="grid gap-3 md:hidden">
                  {visible.map((record) => (
                    <article
                      key={record.id}
                      className="rounded-2xl border border-line bg-surface p-4"
                    >
                      <div className="flex justify-between gap-3">
                        <div>
                          <p className="font-extrabold">{record.campaign}</p>
                          <p className="mt-1 text-xs text-subtle">
                            {record.date} · {record.subject || "No subject line"}
                          </p>
                        </div>
                        <RecordActions
                          record={record}
                          confirmId={confirmId}
                          onView={() => setViewingId(record.id)}
                          onEdit={() => {
                            setEditingId(record.id);
                            document
                              .getElementById("mailer-form")
                              ?.scrollIntoView({ behavior: "smooth", block: "start" });
                          }}
                          onDelete={() => handleDelete(record.id)}
                        />
                      </div>
                      <div className="mt-4 grid grid-cols-3 border-t border-line-soft pt-3 text-xs">
                        <div>
                          <span className="block text-subtle">Merchants</span>
                          <strong>{record.merchants.length}</strong>
                        </div>
                        <div>
                          <span className="block text-subtle">Open</span>
                          <strong>{Number(record.openRate || 0).toFixed(1)}%</strong>
                        </div>
                        <div>
                          <span className="block text-subtle">Spend</span>
                          <strong>{money(record.spend)}</strong>
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              </>
            )}
          </section>
        </section>

        <section className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-[1.05fr_0.95fr]">
          <aside className="rounded-2xl bg-ink p-6 text-white shadow-panel">
            <div className="flex items-start gap-3">
              <div className="rounded-lg bg-brand p-2">
                <ShieldCheck className="size-5" />
              </div>
              <div>
                <h2 className="text-xl font-extrabold">Campaign overview</h2>
                <p className="mt-2 text-sm leading-relaxed text-panel-copy">
                  For internal use only. Do not upload customer data. KPIs update when
                  records are saved, edited, or deleted, and the eye icon opens
                  merchant-aligned performance.
                </p>
              </div>
            </div>
            <div className="mt-6 flex gap-3 rounded-xl bg-gold p-4 text-ink">
              <Radio className="size-5 shrink-0" />
              <p className="text-sm font-bold">
                Live notification: merchant insights update from your saved campaign
                records.
              </p>
            </div>
            <h3 className="mt-7 font-extrabold">Merchant insights</h3>
            <div className="mt-3 grid gap-3">
              {insights.length === 0 ? (
                <p className="text-sm text-insight">
                  Merchant insights will appear when you save your first campaign.
                </p>
              ) : (
                insights.map((item) => (
                  <div
                    key={item.name}
                    className="flex justify-between gap-4 rounded-xl border border-white/10 bg-white/10 p-3"
                  >
                    <div>
                      <strong>{item.name}</strong>
                      <p className="mt-1 text-xs text-insight">
                        {item.count} campaign{item.count === 1 ? "" : "s"} ·{" "}
                        {item.avgOpen.toFixed(1)}% avg open
                      </p>
                    </div>
                    <strong className="text-sm text-gold">{money(item.spend)}</strong>
                  </div>
                ))
              )}
            </div>
          </aside>

          <div id="mailer-form">
            <CampaignForm
              editing={editing}
              onCancel={() => setEditingId(null)}
              onSave={handleSave}
            />
          </div>
        </section>
      </main>

      <PerformanceDialog
        record={viewing}
        onOpenChange={(open) => {
          if (!open) setViewingId(null);
        }}
        onSave={(patch) => {
          if (!viewing) return;
          update(viewing.id, patch);
        }}
      />
    </div>
  );
}

function KpiCard({
  label,
  icon,
  value,
}: {
  label: string;
  icon: ReactNode;
  value: string;
}) {
  return (
    <article className="rounded-2xl border border-line bg-wash p-5">
      <div className="flex items-center justify-between">
        <span className="text-sm font-bold">{label}</span>
        {icon}
      </div>
      <div className="mt-3 text-4xl font-extrabold tracking-kpi tabular-nums">{value}</div>
    </article>
  );
}

function RecordActions({
  record,
  confirmId,
  onView,
  onEdit,
  onDelete,
}: {
  record: Campaign;
  confirmId: string | null;
  onView: () => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const confirming = confirmId === record.id;
  return (
    <div className="flex justify-end gap-1">
      <Button
        type="button"
        variant="eye"
        size="icon"
        aria-label="View Performance"
        onClick={onView}
      >
        <Eye className="size-4" />
      </Button>
      <Button type="button" variant="ghost" size="icon" aria-label="Edit" onClick={onEdit}>
        <Pencil className="size-4" />
      </Button>
      {confirming ? (
        <Button type="button" variant="danger" size="chip" onClick={onDelete}>
          Confirm
        </Button>
      ) : (
        <Button
          type="button"
          variant="delete"
          size="icon"
          aria-label="Delete"
          onClick={onDelete}
        >
          <Trash2 className="size-4" />
        </Button>
      )}
    </div>
  );
}
