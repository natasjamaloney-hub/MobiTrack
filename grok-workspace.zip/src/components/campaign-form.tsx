import { useEffect, useState, type FormEvent } from "react";
import { Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  todayIso,
  type Campaign,
  type CampaignDraft,
} from "@/lib/campaigns";

type Props = {
  editing: Campaign | null;
  onCancel: () => void;
  onSave: (draft: CampaignDraft) => void;
};

export function CampaignForm({ editing, onCancel, onSave }: Props) {
  const [campaign, setCampaign] = useState("");
  const [subject, setSubject] = useState("");
  const [creativeLink, setCreativeLink] = useState("");
  const [date, setDate] = useState(todayIso());
  const [openRate, setOpenRate] = useState("");
  const [spend, setSpend] = useState("");
  const [merchantInput, setMerchantInput] = useState("");
  const [merchants, setMerchants] = useState<string[]>([]);
  const [message, setMessage] = useState<{ tone: "ok" | "err"; text: string } | null>(
    null,
  );

  useEffect(() => {
    if (!editing) {
      setCampaign("");
      setSubject("");
      setCreativeLink("");
      setDate(todayIso());
      setOpenRate("");
      setSpend("");
      setMerchants([]);
      setMerchantInput("");
      return;
    }
    setCampaign(editing.campaign);
    setSubject(editing.subject);
    setCreativeLink(editing.creativeLink);
    setDate(editing.date);
    setOpenRate(String(editing.openRate));
    setSpend(String(editing.spend));
    setMerchants(editing.merchants);
    setMerchantInput("");
    setMessage(null);
  }, [editing]);

  function addMerchant() {
    const value = merchantInput.trim();
    if (!value) return;
    if (merchants.some((item) => item.toLowerCase() === value.toLowerCase())) return;
    setMerchants((current) => [...current, value]);
    setMerchantInput("");
    setMessage(null);
  }

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    const open = Number(openRate);
    const spendValue = Number(spend);
    if (
      !campaign.trim() ||
      !date ||
      !Number.isFinite(open) ||
      openRate === "" ||
      !Number.isFinite(spendValue) ||
      spend === "" ||
      merchants.length === 0
    ) {
      setMessage({
        tone: "err",
        text: "Please complete all required fields and add at least one merchant.",
      });
      return;
    }
    onSave({
      campaign: campaign.trim(),
      subject: subject.trim(),
      creativeLink: creativeLink.trim(),
      date,
      openRate: open,
      spend: spendValue,
      merchants,
    });
    setMessage({
      tone: "ok",
      text: editing ? "Campaign updated." : "Campaign saved to the dashboard.",
    });
    if (!editing) {
      setCampaign("");
      setSubject("");
      setCreativeLink("");
      setDate(todayIso());
      setOpenRate("");
      setSpend("");
      setMerchants([]);
    }
  }

  return (
    <section className="rounded-2xl bg-surface p-6 shadow-panel">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-extrabold text-ink">Add Mailer Record</h2>
          <p className="mt-1 text-sm text-subtle">
            Add merchants by typing a name and pressing Enter.
          </p>
        </div>
        {editing ? (
          <span className="rounded-full bg-gold-soft px-3 py-1.5 text-xs font-bold text-gold-ink">
            Editing record
          </span>
        ) : null}
      </div>

      <form className="mt-5" onSubmit={handleSubmit} noValidate>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <Label htmlFor="creativeLink">Creative Link</Label>
            <Input
              id="creativeLink"
              type="url"
              value={creativeLink}
              onChange={(event) => setCreativeLink(event.target.value)}
              placeholder="https://"
            />
          </div>
          <div>
            <Label htmlFor="campaignName">Campaign Name *</Label>
            <Input
              id="campaignName"
              required
              value={campaign}
              onChange={(event) => setCampaign(event.target.value)}
              placeholder="Summer mailer"
            />
          </div>
          <div>
            <Label htmlFor="subjectLine">Subject Line</Label>
            <Input
              id="subjectLine"
              value={subject}
              onChange={(event) => setSubject(event.target.value)}
              placeholder="Last chance — offer ends tonight"
            />
          </div>
          <div>
            <Label htmlFor="campaignDate">Date *</Label>
            <Input
              id="campaignDate"
              required
              type="date"
              value={date}
              onChange={(event) => setDate(event.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="openRate">Open % *</Label>
            <Input
              id="openRate"
              required
              type="number"
              min={0}
              max={100}
              step={0.1}
              value={openRate}
              onChange={(event) => setOpenRate(event.target.value)}
              placeholder="24.5"
            />
          </div>
          <div>
            <Label htmlFor="spend">Spend ZAR *</Label>
            <Input
              id="spend"
              required
              type="number"
              min={0}
              step={0.01}
              value={spend}
              onChange={(event) => setSpend(event.target.value)}
              placeholder="45000"
            />
          </div>
          <div className="md:col-span-2">
            <Label htmlFor="merchantInput">Merchants *</Label>
            <div className="flex gap-2">
              <Input
                id="merchantInput"
                className="min-w-0 flex-1"
                value={merchantInput}
                onChange={(event) => setMerchantInput(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") {
                    event.preventDefault();
                    addMerchant();
                  }
                }}
                placeholder="Takealot"
              />
              <Button type="button" onClick={addMerchant} className="shrink-0 px-4">
                Add
              </Button>
            </div>
            {merchants.length > 0 ? (
              <div className="mt-3 flex flex-wrap gap-2">
                {merchants.map((name, index) => (
                  <span
                    key={`${name}-${index}`}
                    className="inline-flex items-center gap-1.5 rounded-full border border-brand-line bg-brand-chip px-2.5 py-1 text-xs font-bold text-brand-ink"
                  >
                    {name}
                    <button
                      type="button"
                      aria-label={`Remove ${name}`}
                      className="leading-none"
                      onClick={() =>
                        setMerchants((current) => current.filter((_, i) => i !== index))
                      }
                    >
                      <X className="size-3" />
                    </button>
                  </span>
                ))}
              </div>
            ) : null}
          </div>
        </div>
        <p
          className={`mt-4 min-h-5 text-sm font-semibold ${
            message?.tone === "err"
              ? "text-danger"
              : message?.tone === "ok"
                ? "text-brand-deep"
                : ""
          }`}
          aria-live="polite"
        >
          {message?.text ?? ""}
        </p>
        <div className="mt-3 flex flex-wrap gap-3">
          <Button type="submit" className="font-extrabold">
            <Save className="size-4" />
            Save & Update Dashboard
          </Button>
          {editing ? (
            <Button type="button" variant="secondary" onClick={onCancel}>
              Cancel edit
            </Button>
          ) : null}
        </div>
      </form>
    </section>
  );
}
