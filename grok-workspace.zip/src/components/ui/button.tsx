import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-xl font-bold transition-[opacity,filter,transform] duration-150 ease-out focus-visible:outline-3 focus-visible:outline-offset-2 focus-visible:outline-brand/40 disabled:pointer-events-none disabled:opacity-60 active:scale-[0.98]",
  {
    variants: {
      variant: {
        default: "bg-brand text-white hover:brightness-95",
        secondary: "bg-button-mute text-ink hover:brightness-95",
        ghost: "bg-transparent text-ink hover:bg-wash",
        danger: "bg-danger text-white hover:brightness-95",
        eye: "bg-transparent text-brand-deep hover:bg-brand-chip",
        delete: "bg-transparent text-danger hover:bg-danger-soft",
      },
      size: {
        default: "px-5 py-3",
        sm: "px-4 py-2.5 text-sm",
        icon: "size-9 p-2",
        chip: "px-2 py-1 text-xs",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

type ButtonProps = React.ComponentProps<"button"> &
  VariantProps<typeof buttonVariants> & {
    asChild?: boolean;
  };

function Button({ className, variant, size, asChild = false, ...props }: ButtonProps) {
  const Comp = asChild ? Slot : "button";
  return (
    <Comp className={cn(buttonVariants({ variant, size, className }))} {...props} />
  );
}

export { Button, buttonVariants };
