import * as React from "react";
import { cn } from "@/lib/utils";

function Input({ className, type, ...props }: React.ComponentProps<"input">) {
  return (
    <input
      type={type}
      className={cn(
        "w-full rounded-xl border border-line-strong bg-surface px-3 py-3 text-ink outline-none transition-[box-shadow,border-color] duration-150 placeholder:text-faint focus-visible:outline-3 focus-visible:outline-offset-2 focus-visible:outline-brand/40",
        className,
      )}
      {...props}
    />
  );
}

export { Input };
