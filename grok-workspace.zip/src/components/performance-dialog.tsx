import { useEffect, useMemo, useState } from "react";
import { Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { money, movement, type Campaign, type MerchantSale } from "@/lib/campaigns";
import { cn } from "@/lib/utils";

type Props = {
  record: Campaign | null;
  onOpenChange: (open: boolean) => void;
  onSave: (patch: {
    periodFrom: string;
    periodTo: string;
    customers: number;
    merchantSales: MerchantSale[];
    spend: number;
  }) => void;
};

export function PerformanceDialog({ record, onOpenChange, onSave }: Props) {
  const [periodFrom, setPeriodFrom] = useState("");
  const [periodTo, setPeriodTo] = useState("");
  const [customers, setCustomers] = useState("");
  const [sales, setSales] = useState<MerchantSale[]>([]);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!record) {
      setMessage("");
      return;
    }
    setPeriodFrom(record.periodFrom);
    setPeriodTo(record.periodTo);
    setCustomers(record.customers ? String(record.customers) : "");
    setSales(
      record.merchants.map((name) => {
        const existing = record.merchantSales.find((item) => item.name === name);
        return existing ?? { name, current: 0, previous: 0 };
      }),
    );
    setMessage("");
  }, [record]);

  const summary = useMemo(() => {
    const from = periodFrom || "start date";
    const to = periodTo || "end date";
    const count = customers || "0";
    return `Selected period: ${from} to ${to} · ${count} customers`;
  }, [periodFrom, periodTo, customers]);

  function updateSale(index: number, key: "current" | "previous", value: string) {
    setSales((current) =>
      current.map((item, i) =>
        i === index ? { ...item, [key]: Number(value) || 0 } : item,
      ),
    );
  }

  function handleSave() {
    if (!record) return;
    const total = sales.reduce((sum, item) => sum + item.current, 0);
    onSave({
      periodFrom,
      periodTo,
      customers: Number(customers || 0),
      merchantSales: sales,
      spend: total > 0 ? total : record.spend,
    });
    setMessage("Performance saved and dashboard updated.");
    window.setTimeout(() => onOpenChange(false), 600);
  }

  return (
    <Dialog open={!!record} onOpenChange={onOpenChange}>
      <DialogContent aria-describedby={undefined}>
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-bold tracking-section text-brand uppercase">
              Merchant-aligned performance
            </p>
            <DialogTitle className="mt-1">{record?.campaign ?? ""}</DialogTitle>
            <DialogDescription className="sr-only">
              Compare selected-period sales against last month for each merchant.
            </DialogDescription>
          </div>
          <Button
            type="button"
            variant="secondary"
            size="icon"
            aria-label="Close campaign performance"
            onClick={() => onOpenChange(false)}
          >
            <X className="size-5" />
          </Button>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-3">
          <div>
            <Label htmlFor="periodFrom">Measurement Period From</Label>
            <Input
              id="periodFrom"
              type="date"
              value={periodFrom}
              onChange={(event) => setPeriodFrom(event.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="periodTo">Measurement Period To</Label>
            <Input
              id="periodTo"
              type="date"
              value={periodTo}
              onChange={(event) => setPeriodTo(event.target.value)}
            />
          </div>
          <div>
            <Label htmlFor="customerCount">Customer count</Label>
            <Input
              id="customerCount"
              type="number"
              min={0}
              value={customers}
              onChange={(event) => setCustomers(event.target.value)}
            />
          </div>
        </div>

        <div className="mt-5 rounded-xl bg-brand-soft p-4 text-brand-deep">
          <p className="text-sm font-bold">{summary}</p>
        </div>

        <h3 className="mt-6 text-lg font-extrabold text-ink">Overall Sales Movement</h3>
        <div className="mt-3 grid grid-cols-1 gap-4 md:grid-cols-2">
          {sales.map((item, index) => {
            const stat = movement(item.current, item.previous);
            return (
              <article key={item.name} className="rounded-2xl border border-line p-4">
                <div className="flex justify-between gap-3">
                  <h4 className="font-extrabold text-ink">{item.name}</h4>
                  <span
                    className={cn(
                      "shrink-0 rounded-full px-2.5 py-1 text-xs font-extrabold whitespace-nowrap",
                      stat.direction === "up" && "bg-brand-chip text-brand-deep",
                      stat.direction === "down" && "bg-danger-soft text-danger",
                      stat.direction === "flat" && "bg-gold-soft text-gold-ink",
                    )}
                  >
                    {stat.label} {Math.abs(stat.pct).toFixed(1)}%
                  </span>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <label className="text-xs font-bold text-ink">
                    Selected Period Sales
                    <Input
                      className="mt-1 rounded-lg py-2 text-sm"
                      type="number"
                      min={0}
                      value={item.current}
                      onChange={(event) =>
                        updateSale(index, "current", event.target.value)
                      }
                    />
                  </label>
                  <label className="text-xs font-bold text-ink">
                    Comparable Last Month
                    <Input
                      className="mt-1 rounded-lg py-2 text-sm"
                      type="number"
                      min={0}
                      value={item.previous}
                      onChange={(event) =>
                        updateSale(index, "previous", event.target.value)
                      }
                    />
                  </label>
                </div>
                <p className="mt-3 text-sm font-bold text-ink">
                  {money(item.current)}
                  <span className="ml-2 font-semibold text-subtle">
                    vs {money(item.previous)}
                  </span>
                </p>
              </article>
            );
          })}
        </div>

        <p className="mt-4 min-h-5 text-sm font-semibold text-brand-deep" aria-live="polite">
          {message}
        </p>
        <div className="mt-3 flex justify-end">
          <Button type="button" className="font-extrabold" onClick={handleSave}>
            <Save className="size-4" />
            Save
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
