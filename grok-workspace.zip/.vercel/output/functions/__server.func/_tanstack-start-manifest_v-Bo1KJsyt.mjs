//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bo1KJsyt.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-1aVxmbiz.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-1aVxmbiz.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-gcAEcXca.js"]
	}
} });
//#endregion
export { tsrStartManifest };
