import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Search, c as Radio, d as MailOpen, f as Inbox, g as Activity, h as Banknote, i as ShieldCheck, l as Pencil, m as Database, o as Save, p as Eye, r as Trash2, s as RefreshCw, t as X, u as Mail } from "../_libs/lucide-react.mjs";
import { a as DialogPortal$1, c as Slot, i as DialogOverlay$1, n as DialogContent$1, o as DialogTitle$1, r as DialogDescription$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Do4CT2BG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 rounded-xl font-bold transition-[opacity,filter,transform] duration-150 ease-out focus-visible:outline-3 focus-visible:outline-offset-2 focus-visible:outline-brand/40 disabled:pointer-events-none disabled:opacity-60 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-brand text-white hover:brightness-95",
			secondary: "bg-button-mute text-ink hover:brightness-95",
			ghost: "bg-transparent text-ink hover:bg-wash",
			danger: "bg-danger text-white hover:brightness-95",
			eye: "bg-transparent text-brand-deep hover:bg-brand-chip",
			delete: "bg-transparent text-danger hover:bg-danger-soft"
		},
		size: {
			default: "px-5 py-3",
			sm: "px-4 py-2.5 text-sm",
			icon: "size-9 p-2",
			chip: "px-2 py-1 text-xs"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("w-full rounded-xl border border-line-strong bg-surface px-3 py-3 text-ink outline-none transition-[box-shadow,border-color] duration-150 placeholder:text-faint focus-visible:outline-3 focus-visible:outline-offset-2 focus-visible:outline-brand/40", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("mb-2 block text-sm font-bold text-ink", className),
		...props
	});
}
var STORAGE_KEY = "mobicred-dashboard-records-v1";
var money = (n) => new Intl.NumberFormat("en-ZA", {
	style: "currency",
	currency: "ZAR",
	maximumFractionDigits: 0
}).format(Number.isFinite(n) ? n : 0);
function uid() {
	return `local-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
var SEED = [
	{
		id: "seed-spend-voucher",
		campaign: "Spend R600 Get R200 Voucher",
		subject: "Shop with Mobicred — R200 voucher waiting for you",
		creativeLink: "https://mobicred.co.za/competitions-and-promotions",
		date: "2026-09-15",
		openRate: 31.4,
		spend: 184500,
		merchants: [
			"Takealot",
			"Checkers Sixty60",
			"Superbalist"
		],
		periodFrom: "2026-09-15",
		periodTo: "2026-09-21",
		customers: 12840,
		merchantSales: [
			{
				name: "Takealot",
				current: 92e3,
				previous: 71e3
			},
			{
				name: "Checkers Sixty60",
				current: 54e3,
				previous: 61e3
			},
			{
				name: "Superbalist",
				current: 38500,
				previous: 30200
			}
		],
		createdAt: "2026-09-15T08:00:00.000Z"
	},
	{
		id: "seed-takealot-credit",
		campaign: "takealot.credit R500 Mailer",
		subject: "Apply, shop, get a R500 Takealot voucher",
		creativeLink: "https://mobicred.co.za",
		date: "2026-09-08",
		openRate: 26.8,
		spend: 156200,
		merchants: ["Takealot"],
		periodFrom: "2026-09-08",
		periodTo: "2026-09-14",
		customers: 9640,
		merchantSales: [{
			name: "Takealot",
			current: 156200,
			previous: 128400
		}],
		createdAt: "2026-09-08T09:30:00.000Z"
	},
	{
		id: "seed-sixty60",
		campaign: "Checkers Sixty60 Pay with Mobicred",
		subject: "Groceries in 60 minutes — pay the Mobicred way",
		creativeLink: "https://mobicred.co.za",
		date: "2026-08-28",
		openRate: 22.1,
		spend: 97800,
		merchants: ["Checkers Sixty60", "Shoprite"],
		periodFrom: "2026-08-28",
		periodTo: "2026-09-04",
		customers: 7420,
		merchantSales: [{
			name: "Checkers Sixty60",
			current: 71200,
			previous: 68800
		}, {
			name: "Shoprite",
			current: 26600,
			previous: 30100
		}],
		createdAt: "2026-08-28T07:45:00.000Z"
	},
	{
		id: "seed-spend-win",
		campaign: "Mobicred Spend & Win 2026",
		subject: "Every swipe is an entry — spend and win this month",
		creativeLink: "https://mobicred.co.za/competitions-and-promotions",
		date: "2026-08-12",
		openRate: 34.9,
		spend: 211400,
		merchants: [
			"Makro",
			"Game",
			"Mr Price"
		],
		periodFrom: "2026-08-12",
		periodTo: "2026-08-31",
		customers: 18620,
		merchantSales: [
			{
				name: "Makro",
				current: 98400,
				previous: 81200
			},
			{
				name: "Game",
				current: 67300,
				previous: 70500
			},
			{
				name: "Mr Price",
				current: 45700,
				previous: 38900
			}
		],
		createdAt: "2026-08-12T10:00:00.000Z"
	},
	{
		id: "seed-woolworths",
		campaign: "Woolworths Weekend Edit",
		subject: "The weekend edit is live — pay later with Mobicred",
		creativeLink: "https://mobicred.co.za",
		date: "2026-07-25",
		openRate: 19.6,
		spend: 64300,
		merchants: ["Woolworths", "Superbalist"],
		periodFrom: "2026-07-25",
		periodTo: "2026-07-27",
		customers: 4180,
		merchantSales: [{
			name: "Woolworths",
			current: 41200,
			previous: 39800
		}, {
			name: "Superbalist",
			current: 23100,
			previous: 27400
		}],
		createdAt: "2026-07-25T11:20:00.000Z"
	}
];
function readStorage() {
	if (typeof window === "undefined") return null;
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (raw === null) return null;
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}
function writeStorage(records) {
	if (typeof window === "undefined") return;
	localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}
var useDashboard = create((set, get) => ({
	records: [],
	hydrated: false,
	hydrate: () => {
		const stored = readStorage();
		const records = stored ?? SEED;
		if (stored === null) writeStorage(records);
		set({
			records,
			hydrated: true
		});
	},
	refresh: () => {
		set({ records: readStorage() ?? get().records });
	},
	create: (draft) => {
		const record = {
			id: uid(),
			campaign: draft.campaign,
			subject: draft.subject,
			creativeLink: draft.creativeLink,
			date: draft.date,
			openRate: draft.openRate,
			spend: draft.spend,
			merchants: draft.merchants,
			periodFrom: "",
			periodTo: "",
			customers: 0,
			merchantSales: draft.merchants.map((name) => ({
				name,
				current: 0,
				previous: 0
			})),
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		const records = [...get().records, record];
		writeStorage(records);
		set({ records });
	},
	update: (id, patch) => {
		const records = get().records.map((item) => item.id === id ? {
			...item,
			...patch,
			id: item.id
		} : item);
		writeStorage(records);
		set({ records });
	},
	remove: (id) => {
		const records = get().records.filter((item) => item.id !== id);
		writeStorage(records);
		set({ records });
	},
	loadSample: () => {
		writeStorage(SEED);
		set({ records: SEED });
	}
}));
function sortedCampaigns(records) {
	return [...records].sort((a, b) => {
		const byDate = new Date(b.date).getTime() - new Date(a.date).getTime();
		if (byDate !== 0) return byDate;
		return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
	});
}
function matchesQuery(record, query) {
	if (!query) return true;
	return `${record.campaign} ${record.subject} ${record.merchants.join(" ")}`.toLowerCase().includes(query.toLowerCase());
}
function kpiTotals(records) {
	const total = records.length;
	return {
		total,
		open: total === 0 ? 0 : records.reduce((sum, item) => sum + Number(item.openRate || 0), 0) / total,
		spend: records.reduce((sum, item) => sum + Number(item.spend || 0), 0)
	};
}
function merchantInsights(records) {
	const map = /* @__PURE__ */ new Map();
	for (const record of records) for (const name of record.merchants) {
		const current = map.get(name) ?? {
			count: 0,
			open: 0,
			spend: 0
		};
		current.count += 1;
		current.open += Number(record.openRate || 0);
		current.spend += Number(record.spend || 0);
		map.set(name, current);
	}
	return [...map.entries()].map(([name, value]) => ({
		name,
		count: value.count,
		avgOpen: value.open / value.count,
		spend: value.spend
	})).sort((a, b) => b.spend - a.spend).slice(0, 5);
}
function todayIso() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function movement(current, previous) {
	const delta = current - previous;
	return {
		delta,
		pct: previous ? delta / previous * 100 : 0,
		direction: delta > 0 ? "up" : delta < 0 ? "down" : "flat",
		label: delta > 0 ? "Up" : delta < 0 ? "Down" : "No change"
	};
}
function CampaignForm({ editing, onCancel, onSave }) {
	const [campaign, setCampaign] = (0, import_react.useState)("");
	const [subject, setSubject] = (0, import_react.useState)("");
	const [creativeLink, setCreativeLink] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(todayIso());
	const [openRate, setOpenRate] = (0, import_react.useState)("");
	const [spend, setSpend] = (0, import_react.useState)("");
	const [merchantInput, setMerchantInput] = (0, import_react.useState)("");
	const [merchants, setMerchants] = (0, import_react.useState)([]);
	const [message, setMessage] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!editing) {
			setCampaign("");
			setSubject("");
			setCreativeLink("");
			setDate(todayIso());
			setOpenRate("");
			setSpend("");
			setMerchants([]);
			setMerchantInput("");
			return;
		}
		setCampaign(editing.campaign);
		setSubject(editing.subject);
		setCreativeLink(editing.creativeLink);
		setDate(editing.date);
		setOpenRate(String(editing.openRate));
		setSpend(String(editing.spend));
		setMerchants(editing.merchants);
		setMerchantInput("");
		setMessage(null);
	}, [editing]);
	function addMerchant() {
		const value = merchantInput.trim();
		if (!value) return;
		if (merchants.some((item) => item.toLowerCase() === value.toLowerCase())) return;
		setMerchants((current) => [...current, value]);
		setMerchantInput("");
		setMessage(null);
	}
	function handleSubmit(event) {
		event.preventDefault();
		const open = Number(openRate);
		const spendValue = Number(spend);
		if (!campaign.trim() || !date || !Number.isFinite(open) || openRate === "" || !Number.isFinite(spendValue) || spend === "" || merchants.length === 0) {
			setMessage({
				tone: "err",
				text: "Please complete all required fields and add at least one merchant."
			});
			return;
		}
		onSave({
			campaign: campaign.trim(),
			subject: subject.trim(),
			creativeLink: creativeLink.trim(),
			date,
			openRate: open,
			spend: spendValue,
			merchants
		});
		setMessage({
			tone: "ok",
			text: editing ? "Campaign updated." : "Campaign saved to the dashboard."
		});
		if (!editing) {
			setCampaign("");
			setSubject("");
			setCreativeLink("");
			setDate(todayIso());
			setOpenRate("");
			setSpend("");
			setMerchants([]);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-surface p-6 shadow-panel",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-extrabold text-ink",
				children: "Add Mailer Record"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-subtle",
				children: "Add merchants by typing a name and pressing Enter."
			})] }), editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-gold-soft px-3 py-1.5 text-xs font-bold text-gold-ink",
				children: "Editing record"
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-5 grid grid-cols-1 gap-4 md:grid-cols-2",
			onSubmit: handleSubmit,
			noValidate: true,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "creativeLink",
					children: "Creative Link"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "creativeLink",
					type: "url",
					value: creativeLink,
					onChange: (event) => setCreativeLink(event.target.value),
					placeholder: "https://"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "campaignName",
					children: "Campaign Name *"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "campaignName",
					required: true,
					value: campaign,
					onChange: (event) => setCampaign(event.target.value),
					placeholder: "Summer mailer"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "subjectLine",
					children: "Subject Line"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "subjectLine",
					value: subject,
					onChange: (event) => setSubject(event.target.value),
					placeholder: "Last chance — offer ends tonight"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "campaignDate",
					children: "Date *"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "campaignDate",
					required: true,
					type: "date",
					value: date,
					onChange: (event) => setDate(event.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "openRate",
					children: "Open % *"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "openRate",
					required: true,
					type: "number",
					min: 0,
					max: 100,
					step: .1,
					value: openRate,
					onChange: (event) => setOpenRate(event.target.value),
					placeholder: "24.5"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "spend",
					children: "Spend ZAR *"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "spend",
					required: true,
					type: "number",
					min: 0,
					step: .01,
					value: spend,
					onChange: (event) => setSpend(event.target.value),
					placeholder: "45000"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "merchantInput",
							children: "Merchants *"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "merchantInput",
								className: "min-w-0 flex-1",
								value: merchantInput,
								onChange: (event) => setMerchantInput(event.target.value),
								onKeyDown: (event) => {
									if (event.key === "Enter") {
										event.preventDefault();
										addMerchant();
									}
								},
								placeholder: "Takealot"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: addMerchant,
								className: "shrink-0 px-4",
								children: "Add"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: merchants.map((name, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1.5 rounded-full border border-brand-line bg-brand-chip px-2.5 py-1 text-xs font-bold text-brand-ink",
								children: [name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": `Remove ${name}`,
									className: "leading-none",
									onClick: () => setMerchants((current) => current.filter((_, i) => i !== index)),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
								})]
							}, `${name}-${index}`))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `min-h-5 text-sm font-semibold md:col-span-2 ${message?.tone === "err" ? "text-danger" : message?.tone === "ok" ? "text-brand-deep" : ""}`,
					"aria-live": "polite",
					children: message?.text ?? ""
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-3 md:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						className: "font-extrabold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), "Save & Update Dashboard"]
					}), editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						onClick: onCancel,
						children: "Cancel edit"
					}) : null]
				})
			]
		})]
	});
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-ink/62 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
		...props
	});
}
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 max-h-[min(92vh,920px)] w-[calc(100%-2rem)] max-w-4xl -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-2xl bg-surface p-5 shadow-2xl outline-none md:p-7", className),
		...props,
		children
	})] });
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("text-2xl font-extrabold text-ink", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm text-muted", className),
		...props
	});
}
function PerformanceDialog({ record, onOpenChange, onSave }) {
	const [periodFrom, setPeriodFrom] = (0, import_react.useState)("");
	const [periodTo, setPeriodTo] = (0, import_react.useState)("");
	const [customers, setCustomers] = (0, import_react.useState)("");
	const [sales, setSales] = (0, import_react.useState)([]);
	const [message, setMessage] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!record) {
			setMessage("");
			return;
		}
		setPeriodFrom(record.periodFrom);
		setPeriodTo(record.periodTo);
		setCustomers(record.customers ? String(record.customers) : "");
		setSales(record.merchants.map((name) => {
			return record.merchantSales.find((item) => item.name === name) ?? {
				name,
				current: 0,
				previous: 0
			};
		}));
		setMessage("");
	}, [record]);
	const summary = (0, import_react.useMemo)(() => {
		return `Selected period: ${periodFrom || "start date"} to ${periodTo || "end date"} · ${customers || "0"} customers`;
	}, [
		periodFrom,
		periodTo,
		customers
	]);
	function updateSale(index, key, value) {
		setSales((current) => current.map((item, i) => i === index ? {
			...item,
			[key]: Number(value) || 0
		} : item));
	}
	function handleSave() {
		if (!record) return;
		const total = sales.reduce((sum, item) => sum + item.current, 0);
		onSave({
			periodFrom,
			periodTo,
			customers: Number(customers || 0),
			merchantSales: sales,
			spend: total > 0 ? total : record.spend
		});
		setMessage("Performance saved and dashboard updated.");
		window.setTimeout(() => onOpenChange(false), 600);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!record,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			"aria-describedby": void 0,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold tracking-section text-brand uppercase",
							children: "Merchant-aligned performance"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "mt-1",
							children: record?.campaign ?? ""
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
							className: "sr-only",
							children: "Compare selected-period sales against last month for each merchant."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						size: "icon",
						"aria-label": "Close campaign performance",
						onClick: () => onOpenChange(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid grid-cols-1 gap-4 md:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "periodFrom",
							children: "Measurement Period From"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "periodFrom",
							type: "date",
							value: periodFrom,
							onChange: (event) => setPeriodFrom(event.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "periodTo",
							children: "Measurement Period To"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "periodTo",
							type: "date",
							value: periodTo,
							onChange: (event) => setPeriodTo(event.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "customerCount",
							children: "Customer count"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "customerCount",
							type: "number",
							min: 0,
							value: customers,
							onChange: (event) => setCustomers(event.target.value)
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 rounded-xl bg-brand-soft p-4 text-brand-deep",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold",
						children: summary
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-6 text-lg font-extrabold text-ink",
					children: "Overall Sales Movement"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-1 gap-4 md:grid-cols-2",
					children: sales.map((item, index) => {
						const stat = movement(item.current, item.previous);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-2xl border border-line p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "font-extrabold text-ink",
										children: item.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: cn("rounded-full px-2.5 py-1 text-xs font-extrabold", stat.direction === "up" && "bg-brand-chip text-brand-deep", stat.direction === "down" && "bg-danger-soft text-danger", stat.direction === "flat" && "bg-gold-soft text-gold-ink"),
										children: [
											stat.label,
											" ",
											Math.abs(stat.pct).toFixed(1),
											"%"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "text-xs font-bold text-ink",
										children: ["Selected Period Sales", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											className: "mt-1 rounded-lg py-2 text-sm",
											type: "number",
											min: 0,
											value: item.current,
											onChange: (event) => updateSale(index, "current", event.target.value)
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "text-xs font-bold text-ink",
										children: ["Comparable Last Month", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											className: "mt-1 rounded-lg py-2 text-sm",
											type: "number",
											min: 0,
											value: item.previous,
											onChange: (event) => updateSale(index, "previous", event.target.value)
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-sm font-bold text-ink",
									children: [money(item.current), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-2 font-semibold text-subtle",
										children: ["vs ", money(item.previous)]
									})]
								})
							]
						}, item.name);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 min-h-5 text-sm font-semibold text-brand-deep",
					"aria-live": "polite",
					children: message
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						className: "font-extrabold",
						onClick: handleSave,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), "Save"]
					})
				})
			]
		})
	});
}
function Dashboard() {
	const records = useDashboard((state) => state.records);
	const hydrated = useDashboard((state) => state.hydrated);
	const hydrate = useDashboard((state) => state.hydrate);
	const refresh = useDashboard((state) => state.refresh);
	const create = useDashboard((state) => state.create);
	const update = useDashboard((state) => state.update);
	const remove = useDashboard((state) => state.remove);
	const loadSample = useDashboard((state) => state.loadSample);
	const [query, setQuery] = (0, import_react.useState)("");
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [viewingId, setViewingId] = (0, import_react.useState)(null);
	const [confirmId, setConfirmId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		if (!confirmId) return;
		const timer = window.setTimeout(() => setConfirmId(null), 2600);
		return () => window.clearTimeout(timer);
	}, [confirmId]);
	const editing = records.find((item) => item.id === editingId) ?? null;
	const viewing = records.find((item) => item.id === viewingId) ?? null;
	const visible = (0, import_react.useMemo)(() => sortedCampaigns(records).filter((item) => matchesQuery(item, query)), [records, query]);
	const kpis = (0, import_react.useMemo)(() => kpiTotals(records), [records]);
	const insights = (0, import_react.useMemo)(() => merchantInsights(records), [records]);
	function handleSave(draft) {
		if (editing) {
			const merchantsChanged = draft.merchants.join("|") !== editing.merchants.join("|");
			update(editing.id, {
				...draft,
				merchantSales: merchantsChanged ? draft.merchants.map((name) => {
					return editing.merchantSales.find((item) => item.name === name) ?? {
						name,
						current: 0,
						previous: 0
					};
				}) : editing.merchantSales
			});
			setEditingId(null);
			return;
		}
		create(draft);
	}
	function handleDelete(id) {
		if (confirmId !== id) {
			setConfirmId(id);
			return;
		}
		remove(id);
		setConfirmId(null);
		if (editingId === id) setEditingId(null);
	}
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardSkeleton, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-canvas text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "bg-ink text-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1.5 bg-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-[76px] w-full max-w-[1440px] items-center justify-between px-5 md:px-7",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex size-10 items-center justify-center rounded-xl bg-brand text-xl font-extrabold text-white",
							children: "M"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-extrabold tracking-brand",
							children: "MOBICRED"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold tracking-wide text-gold",
							children: "MARKETING INTELLIGENCE"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden items-center gap-2 text-sm font-semibold text-gold sm:flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-4" }), "Live Dashboard + Performance Eye"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto w-full max-w-[1440px] px-4 py-7 md:px-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl bg-surface p-5 shadow-panel md:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-6 xl:flex-row xl:items-start xl:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-2 text-xs font-bold tracking-kicker text-brand uppercase",
									children: "Internal campaign workspace"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "text-3xl leading-tight font-extrabold text-ink md:text-4xl",
									children: "Mobicred Marketing"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-muted",
									children: "Email Performance Overview - Live"
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-2 rounded-full bg-gold-wash px-3 py-2 text-xs font-bold text-gold-ink",
									"aria-live": "polite",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "size-4" }), "Local storage"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									size: "sm",
									onClick: refresh,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" }), "Refresh"]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-7 grid grid-cols-1 items-center gap-4 lg:grid-cols-[1fr_auto]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "relative block",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sr-only",
										children: "Search campaigns"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute top-1/2 left-4 size-5 -translate-y-1/2 text-faint" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "border-line bg-search py-3.5 pr-4 pl-11",
										type: "search",
										placeholder: "Search campaigns, merchants or subject lines",
										value: query,
										onChange: (event) => setQuery(event.target.value)
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-ink",
									children: records.length
								}), " records"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
									label: "Total",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-5 text-brand" }),
									value: String(kpis.total)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
									label: "Avg Open",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailOpen, { className: "size-5 text-brand" }),
									value: `${kpis.open.toFixed(1)}%`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
									label: "Spend",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, { className: "size-5 text-brand" }),
									value: money(kpis.spend)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "mt-8",
							"aria-labelledby": "records-heading",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-3 flex items-center justify-between",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									id: "records-heading",
									className: "text-xl font-extrabold text-ink",
									children: "Campaign Records"
								})
							}), visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border-2 border-dashed border-line px-5 py-12 text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, { className: "mx-auto mb-3 size-9 text-brand" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-extrabold text-ink",
										children: records.length === 0 ? "No campaign records yet" : "No matching campaigns"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-subtle",
										children: records.length === 0 ? "Add your first mailer record below to bring this dashboard to life." : "Try a different search, or clear the filter to see every record."
									}),
									records.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										className: "mt-5",
										onClick: loadSample,
										children: "Load sample campaigns"
									}) : null
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "hidden overflow-x-auto rounded-2xl border border-line md:block",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "min-w-full text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										className: "bg-ink text-white",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-4 text-left font-bold",
												children: "Date"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-4 text-left font-bold",
												children: "Campaign"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-4 text-left font-bold",
												children: "Merchants"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-4 text-left font-bold",
												children: "Open"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-4 text-left font-bold",
												children: "Spend"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-4 text-right font-bold",
												children: "Actions"
											})
										] })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: visible.map((record) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t border-line-soft hover:bg-search",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-4 whitespace-nowrap",
												children: record.date
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "px-4 py-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: record.campaign }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-1 text-xs text-subtle",
													children: record.subject || "No subject line"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-4",
												children: record.merchants.join(", ") || "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "px-4 py-4 font-bold",
												children: [Number(record.openRate || 0).toFixed(1), "%"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-4 font-bold",
												children: money(record.spend)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-4",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecordActions, {
													record,
													confirmId,
													onView: () => setViewingId(record.id),
													onEdit: () => {
														setEditingId(record.id);
														document.getElementById("mailer-form")?.scrollIntoView({
															behavior: "smooth",
															block: "start"
														});
													},
													onDelete: () => handleDelete(record.id)
												})
											})
										]
									}, record.id)) })]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-3 md:hidden",
								children: visible.map((record) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "rounded-2xl border border-line bg-surface p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-extrabold",
											children: record.campaign
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-xs text-subtle",
											children: [
												record.date,
												" · ",
												record.subject || "No subject line"
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecordActions, {
											record,
											confirmId,
											onView: () => setViewingId(record.id),
											onEdit: () => {
												setEditingId(record.id);
												document.getElementById("mailer-form")?.scrollIntoView({
													behavior: "smooth",
													block: "start"
												});
											},
											onDelete: () => handleDelete(record.id)
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-4 grid grid-cols-3 border-t border-line-soft pt-3 text-xs",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-subtle",
												children: "Merchants"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: record.merchants.length })] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-subtle",
												children: "Open"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [Number(record.openRate || 0).toFixed(1), "%"] })] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-subtle",
												children: "Spend"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: money(record.spend) })] })
										]
									})]
								}, record.id))
							})] })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-6 grid grid-cols-1 gap-6 xl:grid-cols-[1.05fr_0.95fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "rounded-2xl bg-ink p-6 text-white shadow-panel",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "rounded-lg bg-brand p-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-xl font-extrabold",
									children: "Campaign overview"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-panel-copy",
									children: "For internal use only. Do not upload customer data. KPIs update when records are saved, edited, or deleted, and the eye icon opens merchant-aligned performance."
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 flex gap-3 rounded-xl bg-gold p-4 text-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-bold",
									children: "Live notification: merchant insights update from your saved campaign records."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-7 font-extrabold",
								children: "Merchant insights"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 grid gap-3",
								children: insights.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-insight",
									children: "Merchant insights will appear when you save your first campaign."
								}) : insights.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-4 rounded-xl border border-white/10 bg-white/10 p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-xs text-insight",
										children: [
											item.count,
											" campaign",
											item.count === 1 ? "" : "s",
											" ·",
											" ",
											item.avgOpen.toFixed(1),
											"% avg open"
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-sm text-gold",
										children: money(item.spend)
									})]
								}, item.name))
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						id: "mailer-form",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CampaignForm, {
							editing,
							onCancel: () => setEditingId(null),
							onSave: handleSave
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PerformanceDialog, {
				record: viewing,
				onOpenChange: (open) => {
					if (!open) setViewingId(null);
				},
				onSave: (patch) => {
					if (!viewing) return;
					update(viewing.id, patch);
				}
			})
		]
	});
}
function KpiCard({ label, icon, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-2xl border border-line bg-wash p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-bold",
				children: label
			}), icon]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 text-4xl font-extrabold tracking-kpi",
			children: value
		})]
	});
}
function RecordActions({ record, confirmId, onView, onEdit, onDelete }) {
	const confirming = confirmId === record.id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-end gap-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "eye",
				size: "icon",
				"aria-label": "View Performance",
				onClick: onView,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				"aria-label": "Edit",
				onClick: onEdit,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
			}),
			confirming ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "danger",
				size: "chip",
				onClick: onDelete,
				children: "Confirm"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "delete",
				size: "icon",
				"aria-label": "Delete",
				onClick: onDelete,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
			})
		]
	});
}
function DashboardSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-canvas",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-[81px] bg-ink",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1.5 bg-gold" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-[1440px] px-4 py-7 md:px-7",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-80 animate-pulse rounded-2xl bg-surface shadow-panel" })
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {});
}
//#endregion
export { Home as component };
